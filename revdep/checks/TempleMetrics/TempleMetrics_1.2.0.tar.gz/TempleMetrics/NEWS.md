#TempleMetrics 1.2.0
  * New code for local linear smooth varying coefficients models

#TempleMetrics 1.1.0
  * Added code for computing conditional distributions using first step quantile regression
  * Added code for computing conditional distributions using first step local linear distribution regression

#TempleMetrics 1.0.0

  * Initial version, code for distribution regression