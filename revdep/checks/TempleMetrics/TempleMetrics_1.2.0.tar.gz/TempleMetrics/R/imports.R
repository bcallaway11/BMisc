#' TempleMetrics: Functions from the Temple Econometrics Reading Group
#'
#' @docType package
#' @name TempleMetrics
#' @import graphics
#' @import stats
#' @import pbapply
NULL
