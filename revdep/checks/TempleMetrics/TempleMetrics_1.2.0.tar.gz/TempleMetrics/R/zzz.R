utils::globalVariables(c("lldrs.inner","G"))
